package easy.tuto.myquizapplication;

public class QuestionAnswer {

    public static String question[] ={
            "Which company owns the android?",
            "Which one is not the programming language?",
            "Where you are watching this video?",
            "Which company owns the Apple?"
    };

    public static String choices[][] = {
            {"Google","Apple","Nokia","Samsung"},
            {"Java","Kotlin","Notepad","Python"},
            {"Facebook","Whatsapp","Instagram","Youtube"},
            {"Google","Apple","Nokia","Samsung"}
    };

    public static String correctAnswers[] = {
            "Google",
            "Notepad",
            "Youtube",
            "Apple"
    };

}
